package DDFW;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class basic_logintest {
	public static String login(String uid,String pwd)
	{
		String a_result;
		System.setProperty("web driver.chrome.driver", "chromedriver.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com//login");
				dr.findElement(By.xpath("//input[@class='email']")).sendKeys(uid);
				dr.findElement(By.xpath("//input[@class='password']")).sendKeys(pwd);
	            dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	            
	            
	            String a_eid = dr.findElement(By.xpath("//div[@class='header-links']//child::li[1]/a")).getText();
	            dr.close();
	            return a_eid;
}
	}


