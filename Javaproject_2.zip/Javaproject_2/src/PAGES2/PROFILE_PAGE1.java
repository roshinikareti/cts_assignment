package PAGES2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PROFILE_PAGE1 {
	By xp_profilename = By.xpath("/html/body/div[4]/div[1]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a");
	WebDriver dr3;
	
	public PROFILE_PAGE1(WebDriver dr) 
	{
		dr3 = dr;
	}
	
    public String get_profilename()
    {
    	String pname = dr3.findElement(xp_profilename).getText();
    	return pname;
    }
}
