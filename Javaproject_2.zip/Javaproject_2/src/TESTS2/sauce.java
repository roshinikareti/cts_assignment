package TESTS2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import PAGES2.HOME_PAGE1;
import PAGES2.LOGIN_PAGE1;



public class sauce {
	WebDriver dr;
	LOGIN_PAGE1 lp;
	 @Test
	 public void logintest1() {
		 lp.do_login("standard_user","secret_sauce");
	 }
	
	@BeforeClass
	public void launchbrowser()
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		dr = new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		  String actTitle=dr.getTitle();
		  String expTitle="Swag Labs";
		  Assert.assertEquals(actTitle, expTitle);
		  {
			  System.out.println("title matches");
		  }
		lp = new LOGIN_PAGE1(dr);
		
	}
  @AfterClass
  public void productlabel()
  {
	  String actLabel=dr.findElement(By.className("product_label")).getText();
	  String expLabel="Products";
	  Assert.assertEquals(actLabel, expLabel);
	  {
		  System.out.println("Label matches");
	  }
	  
	   }
 }


