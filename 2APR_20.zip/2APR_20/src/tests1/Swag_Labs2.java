package tests1;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.baseclass1.Utilities1;
import com.excel_util1.excel_logindata1;

import pages1.Loginpage1;
import pages1.Productspage1;

public class Swag_Labs2 extends excel_logindata1{ 
	 
	WebDriver dr;
	Loginpage1 lp;
	Productspage1 hp;
	
	@Test
	public void title()
	{
		String actual= lp.title();
		String expected="Swag Labs";
		 Assert.assertEquals(actual, expected);
	}
	
	@Test(dataProvider="login_data")
	public void textcheck(String uname,String pwd,String exp)
	{
		lp.do_login(uname,pwd);
		String actual=hp.check();
		System.out.println(actual);
		 Assert.assertEquals(actual, exp);
	}
	
	
	@BeforeClass
 public void launchbrowser1()
 {
	  get_test_data();
	  System.out.println(testdata);
 }
	
	@BeforeMethod
  public void launch_Browser()
  {
	   dr=Utilities1.launch_browser("chrome","https://www.saucedemo.com/");
	   lp= new Loginpage1(dr);
	   hp=new Productspage1(dr);
  }
	@BeforeClass
	public void launch_Browser1()
	{
		dr=Utilities1.launch_browser("firefox","https://www.saucedemo.com/");
		   lp= new Loginpage1(dr);
		   hp=new Productspage1(dr);
	}
  @DataProvider(name="login_data")
  public String[][] get_login_data()
  {
	   return testdata;
  }
}
