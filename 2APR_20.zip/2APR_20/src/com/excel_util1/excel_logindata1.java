package com.excel_util1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_logindata1 {
public static String filename = "C:/Users/user/Desktop/Camera/full.xlsx" , sheetname = "LOGIN_DATA";
	
	public static String[][] testdata;
	
	public static int rowno,colno;
	
	public static void get_test_data()
	{
		testdata = new String[2][3];
		
		int c; String s = null, s1 = null , s2 = null;
		
		for(rowno=1;rowno<=2;rowno++)
		{
			try {
				
				System.out.println("in get test data row = " + rowno);
				File f = new File(filename);
				FileInputStream fis = new FileInputStream(f);
				XSSFWorkbook wb = new XSSFWorkbook(fis);
				XSSFSheet sheet = wb.getSheet(sheetname);
				XSSFRow row = sheet.getRow(rowno);
				XSSFCell cell1 =row.getCell(0);
				
				testdata[rowno-1][0] = cell1.getStringCellValue();
				XSSFCell cell2 =row.getCell(1);
				testdata[rowno-1][1] = cell2.getStringCellValue();
				XSSFCell cell3 =row.getCell(2);
				testdata[rowno-1][2] = cell3.getStringCellValue();		
		}
			catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			catch (IOException e) {
				e.printStackTrace();
			}
			
	}
}

}
