package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Productspage {
WebDriver dr2;
	
	public Productspage(WebDriver dr)
	{
		dr2=dr;
	}
	
public String check() {
	String actual=dr2.findElement(By.xpath("//*[@id=\"inventory_filter_container\"]/div")).getText();
	//System.out.println(actual);
	dr2.close();
	return actual;
}
	}


