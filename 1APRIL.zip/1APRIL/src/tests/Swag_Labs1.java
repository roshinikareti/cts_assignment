package tests;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.baseclass.Utilities;
import com.excel_util.excel_logindata;


import pages.Loginpage;
import pages.Productspage;

public class Swag_Labs1 extends excel_logindata{ 
	WebDriver dr;
	Loginpage lp;
	Productspage hp;
	
	@Test
	public void title()
	{
		String actual= lp.title();
		String expected="Swag Labs";
		 Assert.assertEquals(actual, expected);
	}
	
	@Test(dataProvider="login_data")
	public void textcheck(String uname,String pwd,String exp)
	{
		lp.do_login(uname,pwd);
		String actual=hp.check();
		System.out.println(actual);
		 Assert.assertEquals(actual, exp);
	}
	
	
	@BeforeClass
  public void launchbrowser1()
  {
	  get_test_data();
	  System.out.println(testdata);
  }
  
	@BeforeMethod
   public void launch_Browser()
   {
	   dr=Utilities.launch_browser("chrome","https://www.saucedemo.com/");
	   lp= new Loginpage(dr);
	   hp=new Productspage(dr);
   }
   @DataProvider(name="login_data")
   public String[][] get_login_data()
   {
	   return testdata;
   }
 }

 