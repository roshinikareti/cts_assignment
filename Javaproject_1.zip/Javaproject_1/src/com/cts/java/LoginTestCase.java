package com.cts.java;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginTestCase {

	public String login()
	{
		System.setProperty("web driver.chrome.driver", "chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("http://demowebshop.tricentis.com//");
		driver.findElement(By.className("ico-login")).click();
		driver.findElement(By.id("Email")).sendKeys("roshinirosh963@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("roshini@123");
		//tagname[@attribute='value']
		//input[@value='Log in']
		driver.findElement(By.xpath("//input[@value=\'Log in\']")).click();
	   // compare the expected result &actual result.then decide if the test case is pass/fail.
		
		String act_res = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		
		return act_res;

	}

}
