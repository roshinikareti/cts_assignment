package com.cts.java;

import org.testng.Assert;
import org.testng.annotations.Test;  

public class NewTest2 {
	
	LoginTestCase demoweb;
  @Test
  public void test1() {
	  
	  String act_res;
	  String exp_res = "roshinikareti@gmail.com";
	  
	  demoweb = new LoginTestCase();
	  
	  //this will call the login method, it returns the actual result & is stored in the variable - 'act_res'
	  act_res = demoweb.login();
	  
	  Assert.assertEquals(act_res, exp_res);
  }
}
