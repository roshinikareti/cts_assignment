package com.cts.java;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FirstJava {

	public static void main(String[] args) {
		
		System.setProperty("web driver.chrome.driver", "chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("http://demowebshop.tricentis.com//");
		driver.findElement(By.className("ico-login")).click();
		driver.findElement(By.id("Email")).sendKeys("roshinikareti@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("Angel@44");
		
		driver.findElement(By.xpath("//input[@value=\'Log in\']")).click();
	   
		
		String act_res = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		String exp_res = "roshinikareti@gmail.com";
		
		if(act_res.equals(exp_res))
			System.out.println("TEST CASE PASS");
		else
			System.out.println("TEST CASE FAIL");
	
	
	
	}
	
	

}

