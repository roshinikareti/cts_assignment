package KWDFW1;

public class test {

	public static void main(String[] args) {
		excel2_oprations excel= new excel2_oprations();
		excel.write_excel(0, 1, "STEP_NO");
		excel.write_excel(1, 2, "selenium");
		
	}
}
