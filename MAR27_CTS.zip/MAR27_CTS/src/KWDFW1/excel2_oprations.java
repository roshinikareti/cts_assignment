package KWDFW1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel2_oprations {
	String filename = "C:/Users/user/Desktop/Camera/KWDFW_FILE1.xlsx", sheetname="KEYWORD";
	 
	public String write_excel(int row, int col, String data)
	{String s=null;   
		try{File f = new File(filename);
		FileInputStream fis = new FileInputStream(f);
			 XSSFWorkbook wb = new XSSFWorkbook(fis);
			 XSSFSheet sh = wb.getSheet(sheetname);
			 XSSFRow r = sh.getRow(row);
			 XSSFCell c = r.getCell(col);
			 c.setCellValue(data);
			 FileOutputStream fos = new FileOutputStream(f);
			 wb.write(fos);
			 
			 
		}catch(IOException e){
			// TODO Auto-generated catch block
			 e.printStackTrace();
			 }
		 return s;
		 
	}
	public void write_excel2(int row, int col, String data) {
		String s=null;   
		try{File f = new File(filename);
		FileInputStream fis = new FileInputStream(f);
			 XSSFWorkbook wb = new XSSFWorkbook(fis);
			 XSSFSheet sh = wb.getSheet(sheetname);
			 XSSFRow r = sh.getRow(row);
			 XSSFCell c = r.getCell(col);
			 c.setCellValue(data);
			 FileOutputStream fos = new FileOutputStream(f);
			 wb.write(fos);
			 
			 
		}catch(IOException e){
			// TODO Auto-generated catch block
			 e.printStackTrace();
			 }
	}
	public void write_excel3(int row, int col, String data) {
		String s=null;   
		try{File f = new File(filename);
		FileInputStream fis = new FileInputStream(f);
			 XSSFWorkbook wb = new XSSFWorkbook(fis);
			 XSSFSheet sh = wb.getSheet(sheetname);
			 XSSFRow r = sh.getRow(row);
			 XSSFCell c = r.getCell(col);
			 c.setCellValue(data);
			 FileOutputStream fos = new FileOutputStream(f);
			 wb.write(fos);
			 
			 
		}catch(IOException e){
			// TODO Auto-generated catch block
			 e.printStackTrace();
			 }
	
	         }
             }
             