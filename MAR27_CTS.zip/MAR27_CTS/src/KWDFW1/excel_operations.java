package KWDFW1;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_operations {
	String filename = "C:/Users/user/Desktop/Camera/KWDFW_FILE1.xlsx", sheetname="KEYWORD";
			 
			public String read_excel(int row, int col)
			{
				String s=null;   
				FileInputStream fin;
				try{
					 File f = new File(filename);
					 fin = new FileInputStream(f);
					 XSSFWorkbook wb = new XSSFWorkbook(fin);
					 XSSFSheet sh = wb.getSheet(sheetname);
					 XSSFRow r = sh.getRow(row);
					 XSSFCell c = r.getCell(col);
					 
					 s = c.getStringCellValue();
					 //System.out.println(s);
				}catch(IOException e){
					// TODO Auto-generated catch block
					 e.printStackTrace();
					 }
				 return s;
			}
		}


