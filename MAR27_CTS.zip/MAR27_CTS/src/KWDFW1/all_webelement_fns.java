package KWDFW1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class all_webelement_fns {
WebDriver driver1;
    public all_webelement_fns(WebDriver driver) {
    }
	
	 void all_webelement_fns(WebDriver driver)
	{
		this.driver1 = driver;
	}
	  
	public void enter_txt(String xp, String data)
	{
		driver1.findElement(By.xpath(xp)).sendKeys(data);
	}
	
	public void click(String xp) 
	{
		driver1.findElement(By.xpath(xp)).click();
		
	}
	public void launchChrome(String ur1)
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		driver1 = new ChromeDriver();
		driver1.get(ur1);
	}
	

}

