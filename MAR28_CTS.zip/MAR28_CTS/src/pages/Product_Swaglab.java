package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Product_Swaglab {
	
	WebDriver dr;
	
	By txt = new By.ByClassName("product_label");
	
	
	public Product_Swaglab(WebDriver dr) 
	{
		this.dr = dr;
		
	}
	
	public String Get_text()
	{
		String act_text=dr.findElement(txt).getText();
		return Get_text();
	
	}
	

}
