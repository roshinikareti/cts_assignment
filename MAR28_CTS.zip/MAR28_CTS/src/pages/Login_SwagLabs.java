package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login_SwagLabs {
	
	WebDriver dr;
	
	@FindBy(xpath="//*[@id=\"user-name\"]")
	WebElement uname;
	
	@FindBy(xpath="//*[@id=\"password\"]")
	WebElement pwd;
	
	@FindBy(xpath="//*[@id=\"login_button_container\"]/div/form/input[3]")
	WebElement Login_btn;
	
	public Login_SwagLabs(WebDriver dr)
	{
		
		this.dr=dr;
		PageFactory.initElements(dr,  this);
	}
	public String Get_title()
	{
		String act_title=dr.getTitle();
		return act_title;
	}
	
	public void username(String un)
	{
		uname.sendKeys("standard_user");
	}
	
	public void password(String password)
	{
	    pwd.sendKeys("secret_sauce");
	}
	
	public void Login_click()
	{
		Login_btn.click();
	}
	public void Login(String un, String password)
	{
		this.username(un);
		this.password(password);
		this.Login_click();
	}
}
