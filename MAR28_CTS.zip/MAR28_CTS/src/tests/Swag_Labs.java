package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.Login_SwagLabs;
import pages.Product_Swaglab;


public class Swag_Labs { 
	 
	WebDriver dr;
	Login_SwagLabs lp;
	Product_Swaglab pp; 
	
	
	@BeforeClass
	public void launchbrowser()
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		dr = new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		pp = new Product_Swaglab(dr);
		lp = new Login_SwagLabs(dr);
		
	}
  @Test
  public void logintest1() {
	  
	  String act_title,exp_title="Swag Labs";
	  act_title = lp.Get_title();
      Assert.assertEquals(act_title, exp_title,"Title Mismatch");
	  
	  
	  lp.Login("standard_user","secret_sauce");
	  
  }
  @Test
  public void Test2() {
	  String act_text,exp_text="Products";
	  act_text=pp.Get_text();
	  Assert.assertEquals(exp_text, act_text, "Text Mismatch");
  }
 }

