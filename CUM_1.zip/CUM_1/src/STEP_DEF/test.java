package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test {
	 
	 WebDriver driver;
	
	@Given("^Login page is displayed$")
	public void login_page_is_displayed()  {
	     
	    System.out.println("login page is displayed"); 
		System.setProperty("web driver.chrome.driver", "chromedriver.exe");
	    driver= new ChromeDriver(); 
		driver.get("http://demowebshop.tricentis.com//");
	}

	@When("^User enters login data and clicks ok button$")
	public void user_enters_login_data_and_clicks_ok_button()  {
		driver.findElement(By.linkText("Log in")).click();
		driver.findElement(By.id("Email")).sendKeys("roshinirosh963@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("roshini@123");
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	   
	  }
 
	@Then("^Home page is displayed$")
	public void home_page_is_displayed() {
	    String a_email = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	    SoftAssert sa = new SoftAssert();
	    sa.assertEquals(a_email, "roshinirosh963@gmail.com");
	    sa.assertAll(); 
	}
	@When("^User enters INVALID email id and clicks ok button$")
	public void r4()  {
		driver.findElement(By.linkText("Log in")).click();
		driver.findElement(By.id("Email")).sendKeys("roshinirosh963@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("roshini@123");
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	   
	  }
	@Then("^Login page is displayed with error message - NO customer account found$")
	public void r3() {
	    String a_email = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	    SoftAssert sa = new SoftAssert();
	    sa.assertEquals(a_email, "roshinirosh963@gmail.com");
	    sa.assertAll(); 

}
}